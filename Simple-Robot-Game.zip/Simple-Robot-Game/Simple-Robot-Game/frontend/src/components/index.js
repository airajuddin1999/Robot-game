export { default as Navigation } from "./Navigation";
export { default as Footer } from "./Footer";
export { default as Home } from "./Home";
export { default as Interactions } from "./Interactions";
export { default as Result } from "./Result";
